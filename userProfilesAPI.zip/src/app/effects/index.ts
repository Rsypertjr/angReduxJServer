import {UserEffects} from './user';

export {
    UserEffects
};

export default [
    UserEffects
];